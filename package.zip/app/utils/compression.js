const sharp = require('sharp');
const fs = require('fs');


async function compressImage(inputPath, outputPath, quality) {
  try {
    const data = await sharp(inputPath).webp({ quality }).toBuffer();
    fs.writeFile(outputPath, data, (err) => {
      if (err) {
        console.error(err);
        return err
      } else {
        console.log(`Compressed image saved to ${outputPath}`);
      }
    });
    return data

  } catch (err) {
    console.error(err);
  }
}

const compression = {
  compressImage:compressImage
}

module.exports = compression;

// Example usage:
//compressImage('input.png', 'output.webp', 80);
