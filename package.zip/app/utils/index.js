const encryption = require('./encryption');
const compression = require('./compression');
const generateId = require('./generateid');
module.exports = {
    encryption,
    compression,
    generateId
}